import { Hero } from '../components';

const Landing = () => {
  return (
    <>
      <Hero />
    </>
  );
};
export default Landing;