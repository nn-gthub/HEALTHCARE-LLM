export { default as HomeLayout } from './HomeLayout';
export { default as Login } from './Login';
export { default as Register } from './Register';
export { default as Landing } from './Landing';
export { default as ProfilePage } from './ProfilePage';
export { default as AppointmentsPage } from './AppointmentsPage';
export { default as Patients } from './Patients';
export {default as ManageAppointments } from './ManageAppointments';
export {default as HealthMetrics } from './HealthMetrics';